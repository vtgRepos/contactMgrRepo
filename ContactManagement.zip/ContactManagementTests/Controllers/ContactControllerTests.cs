﻿using ContactManagement.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ContactManagement.Controllers.Tests
{
    [TestClass()]
    public class ContactControllerTests
    {
        private IContactManagerRepository _repository;

        [TestInitialize]
        public void Initialize()
        {
            _repository = new EntityContactManagerRepository();
        }

        [TestMethod()]
        public void CreateTest()
        {
            var controller = new ContactController();

            // Arrange
            Contact contactInfo = new Contact()
            {
                FirstName = "Vijay",
                LastName = "Gujar",
                PhoneNumber = "12345678",
                Email = "Test@gmail.com",
                Status = "Active"
            };

            // Act
            //var result = _repository.CreateContact(contactInfo);

            // Assert
            //Assert.IsTrue(result);
        }
    }
}
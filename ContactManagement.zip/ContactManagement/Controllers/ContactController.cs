﻿using ContactManagement.Models;
using System;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace ContactManagement.Controllers
{
    public class ContactController : Controller
    {
        private IContactManagerRepository _repository;

        public ContactController()
            : this(new EntityContactManagerRepository())
        { }

        public ContactController(IContactManagerRepository repository)
        {
            _repository = repository;
        }

        protected void ValidateContact(Contact contactToValidate)
        {
            if (contactToValidate.FirstName == null || contactToValidate.FirstName.Trim().Length == 0)
                ModelState.AddModelError("FirstName", "First name is required.");
            if (contactToValidate.LastName == null || contactToValidate.LastName.Trim().Length == 0)
                ModelState.AddModelError("LastName", "Last name is required.");
            if (contactToValidate.Email == null || contactToValidate.Email.Trim().Length > 0 && !Regex.IsMatch(contactToValidate.Email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$"))
                ModelState.AddModelError("Email", "Invalid email address.");
            if (contactToValidate.PhoneNumber == null || contactToValidate.PhoneNumber.Trim().Length == 0)
                ModelState.AddModelError("Phone", "Invalid phone number.");
            if (contactToValidate.Status == null || contactToValidate.Status.Trim().Length == 0)
                ModelState.AddModelError("Status", "Status is required.");
        }

        public ActionResult Index()
        {
            return View(_repository.ListContacts());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName,Email,PhoneNumber,Status")] Contact contact)
        {
            ValidateContact(contact);

            if (!ModelState.IsValid)
            {
                return View(contact);
            }

            try
            {
                _repository.CreateContact(contact);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View(contact);
            }
        }

        public ActionResult Edit(int id)
        {
            return View(_repository.GetContact(id));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,Email,PhoneNumber,Status")] Contact contact)
        {
            ValidateContact(contact);

            if (!ModelState.IsValid)
            {
                return View(contact);
            }

            try
            {
                _repository.EditContact(contact);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return View(contact);
            }
        }

        public ActionResult Delete(int id)
        {
            return View(_repository.GetContact(id));
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                _repository.DeleteContact(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;

namespace ContactManagement.Models
{
    public class EntityContactManagerRepository : IContactManagerRepository
    {
        private ContactManagerDBEntities _entities = new ContactManagerDBEntities();

        public Contact GetContact(int id)
        {
            return (from c in _entities.Contacts where c.Id == id select c).FirstOrDefault();
        }

        public IEnumerable<Contact> ListContacts()
        {
            return _entities.Contacts.ToList();
        }

        public Contact CreateContact(Contact contactToCreate)
        {
            _entities.Contacts.Add(contactToCreate);
            _entities.SaveChanges();
            return contactToCreate;
        }

        public Contact EditContact(Contact contactToEdit)
        {
            var originalContact = GetContact(contactToEdit.Id);

            if(originalContact != null)
            {
                originalContact.FirstName = contactToEdit.FirstName;
                originalContact.LastName = contactToEdit.LastName;
                originalContact.PhoneNumber = contactToEdit.PhoneNumber;
                originalContact.Email = contactToEdit.Email;
                originalContact.Status = contactToEdit.Status;
                
                _entities.SaveChanges();
            }

            return contactToEdit;
        }

        public void DeleteContact(int id)
        {
            var originalContact = GetContact(id);
            _entities.Contacts.Remove(originalContact);
            _entities.SaveChanges();
        }
    }
}